package com.psp.psp13.controller;

public class UserRestController {
}
